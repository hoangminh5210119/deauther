
function captivePortalAttack() {
    var ssid = getE("ssid_captive").value;
    var captive_id = getE("captivePortal_id").value;
    var _ssid = "\"" + ssid + "\""
    var _captive_id = "\"" + captive_id + "\""
    var cmd = "run?cmd=captiveattack " + _ssid + " " + _captive_id
    // console.log(cmd);
    getFile(cmd);
}